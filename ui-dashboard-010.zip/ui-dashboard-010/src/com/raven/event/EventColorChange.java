package com.raven.event;

import java.awt.Color;

public interface EventColorChange {

    public void colorChange(Color color);
}
