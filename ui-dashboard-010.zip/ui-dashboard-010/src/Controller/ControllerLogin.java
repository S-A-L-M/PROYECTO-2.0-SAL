/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import com.raven.main.Main;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import loginform.login;

/**
 *
 * @author SENA
 */
public class ControllerLogin implements ActionListener {
    login vistalogin;
    Main vistamain = new Main();    
    /*Variables login*/
    int id = 0;
    String User, Pass;
    
 
    
    
    public ControllerLogin(login vistalogin){
        this.vistalogin = vistalogin;
        this.Iniciar();
        this.vistalogin.BtnLogin.addActionListener(this);
        
    }
    
    public void Iniciar(){
        this.vistalogin.setVisible(true);
        this.vistalogin.setLocationRelativeTo(null);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {   
        if (e.getSource()== this.vistalogin.BtnLogin){
            boolean at = false;
             String User = this.vistalogin.txtusername.getText();
             String Pass = this.vistalogin.txtpassword.getText();
             
             if ("Admin".equals(User)&& "123".equals(Pass)){
                 vistamain.setVisible(true);
                 this.vistalogin.setVisible(false);
                 System.out.println("Bienvenido"+ User);
                 at = true;
                 
             }else {
                 if (at == false){
                     JOptionPane.showMessageDialog(null, "El Usuario o Contraseña no Coinciden con el Registro");
                     this.vistalogin.txtusername.setText("");
                      this.vistalogin.txtpassword.setText("");
                 }
             }
            
        }
        
    }
    
}
