/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainClass;

import Controller.ControllerLogin;
import loginform.login;

/**
 *
 * @author SENA
 */
public class MainClass {

    public static void main(String[] args) {
        login vistalogin = new login();
        ControllerLogin cp = new ControllerLogin(vistalogin);
        cp.Iniciar();
    }

}

